### load data and estimate transmission time relative to symptoms

#### load incubation period from McAloon et al metanalysis:   

##### mu and sigma parameters (95% CIs) of 1.63 (95% CI 1.51 to 1.75) 
####   and 0.50 (95% CI 0.46 to 0.55), respectively. The corresponding 
##### mean (95% CIs) was 5.8 (95% CI 5.0 to 6.7) days.

mca_ip_ml <- 1.63
mca_ip_sdl <- 0.50 
n_sample <- 10000
######
### sample distribution McAloon IP
mca_ip <- rlnorm(n_sample, mca_ip_ml, mca_ip_sdl)
summary(mca_ip)

############## loop for all gamma distributed serial intervals or generation times
colnames(d)
summary(as.factor(d$distribution))
gamma_df <- d[d$distribution=="gamma",]  #### all gammas supply mean and sd
gamma_names <- unique(gamma_df$unique_id)
gamma_names

gamma_df1 <- data.frame()### make a dataframe to collect data from loop
colnames(d)
unique(d$variable)
for(i in 1:length(gamma_names))
{
  df1 <- d[d$unique_id==gamma_names[i],]  ### get data for a particular study
  g_mean <- df1$central_value[df1$variable=="Mean..95..CI...days."] 
  g_sd <- df1$central_value[df1$variable=="SD"] ### get gamma rate parameter for serial interval or generation time
  g_sh <- g_mean^2/(g_sd^2)
  g_r <- g_mean/(g_sd^2)
  si_or_gt1 <- rgamma(n_sample,g_sh, g_r) ##### generate distribution for serial interval or generation time 
  trs1 <- si_or_gt1-mca_ip #### subtract incubation period from serial interval or generation time to estimate transmission time relative to symptom onset
  df2 <- data.frame(study=rep(gamma_names[i], n_sample)) ### collect data in a dataframe
  df2$transmission_parameter <- rep(unique(df1$si_or_gt), n_sample)
  df2$n_gt_or_si <- rep(unique(df1$number_of_infector_infectee_pairs), n_sample)
  df2$si_or_gt <- si_or_gt1
  df2$trs <- trs1 
  df2$si_or_gt_dist <- "gamma"
  gamma_df1<- rbind(gamma_df1, df2)
}
summary(gamma_df1)

############## loop for all normally distributed serial intervals or generation times
colnames(d)
summary(as.factor(d$distribution))
normal_df <- d[d$distribution=="normal",]
normal_names <- unique(normal_df$unique_id)
normal_names

normal_df1 <- data.frame()### make a dataframe to collect data from loop
normal_names
for(i in 1:length(normal_names))
{
  df1 <- d[d$unique_id==normal_names[i],]  ### get data for a particular study
  n_m <- df1$central_value[df1$variable=="Mean..95..CI...days."]
  n_m### get normal mean p for serial interval or generation time
  n_sd <- df1$central_value[df1$variable=="SD"] ### get normal rstandard deviation for serial interval or generation time
  n_sd
  si_or_gt1 <- rnorm(n_sample,n_m, n_sd) ##### generate distribution for serial interval or generation time 
  trs1 <- si_or_gt1-mca_ip #### subtract incubation period from serial interval or generation time to estimate transmission time relative to symptom onset
  df2 <- data.frame(study=rep(normal_names[i], n_sample)) ### collect data in a dataframe
  df2$transmission_parameter <- rep(unique(df1$si_or_gt), n_sample)
  df2$n_gt_or_si <- rep(unique(df1$number_of_infector_infectee_pairs), n_sample)
  df2$si_or_gt <- si_or_gt1
  df2$trs <- trs1 
  df2$si_or_gt_dist <- "normal"
  normal_df1<- rbind(normal_df1, df2)
}
warnings()
################
############## loop for all weibull distributed serial intervals or generation times Ferretti and Nishiura 18
colnames(d)
summary(as.factor(d$distribution))
weibull_df <- d[d$distribution=="weibull",]
weibull_names <- unique(weibull_df$unique_id)
weibull_names

weibull_df1 <- data.frame()### make a dataframe to collect data from loop

for (i in 1:length(weibull_names))
{
  df1 <- d[d$unique_id==weibull_names[i],]
  w_m <- df1$central_value[df1$variable=="Mean..95..CI...days."]
  w_sd <- df1$central_value[df1$variable=="SD"]
  wp <- weibullpar(w_m, w_sd)
  shapex <- wp$shape
  shapex
  scalex <- wp$scale
  scalex
  si_or_gt1 <- rweibull(n_sample,shapex, scalex) ##### generate distribution for serial interval or generation time 
  trs1 <- si_or_gt1-mca_ip #### subtract incubation period from serial interval or generation time to estimate transmission time relative to symptom onset
  df2 <- data.frame(study=rep(weibull_names[i], n_sample)) ### collect data in a dataframe
  df2$transmission_parameter <- rep(unique(df1$si_or_gt), n_sample)
  df2$n_gt_or_si <- rep(unique(df1$number_of_infector_infectee_pairs), n_sample)
  df2$si_or_gt <- si_or_gt1
  df2$trs <- trs1 
  df2$si_or_gt_dist <- "weibull"
  weibull_df1<- rbind(weibull_df1, df2)
}
  
  

############## lognormal distributed serial intervals or generation times
###### lognormal distribution with mean and standard deviation
#sigma <- sqrt(log(v/(mean^2)+1))
#mu <- log(mean) - (sigma)^2/2
### get parameters for kwok

colnames(d)
summary(as.factor(d$distribution))
lognorm_df <- d[d$distribution=="lognormal",]
#### problem with "Chun et al. [39]" - remove for time being..
lognorm_names <- unique(lognorm_df$unique_id)
lognorm_names
unique(d$variable)
lognorm_df1 <- data.frame()### make a dataframe to collect data from loop

for (i in 1:length(lognorm_names)) 
{
df1 <- d[d$unique_id==lognorm_names[i],]  ### get data for a particular study
ln_ml <- df1$central_value[df1$variable=="parameter.1"] ### get lognormal mean log parameter for serial interval or generation time
ln_sdl <- df1$central_value[df1$variable=="parameter.2"] ### get lognormal sd log  parameter for serial interval or generation time
si_or_gt1 <- rlnorm(n_sample,ln_ml, ln_sdl) ##### generate distribution for serial interval or generation time 
trs1 <- si_or_gt1-mca_ip #### subtract incubation period from serial interval or generation time to estimate transmission time relative to symptom onset
df2 <- data.frame(study=rep(lognorm_names[i], n_sample)) ### collect data in a dataframe
df2$transmission_parameter <- rep(unique(df1$si_or_gt), n_sample)
df2$n_gt_or_si <- rep(unique(df1$number_of_infector_infectee_pairs), n_sample)
df2$si_or_gt <- si_or_gt1
df2$trs <- trs1 
df2$si_or_gt_dist <- "lognormal"
lognorm_df1<- rbind(lognorm_df1, df2)
}
summary(lognorm_df1)
hist(lognorm_df1$si_or_gt, xlim=c(0,15), breaks=1000)
ln_large_values <- lognorm_df1[lognorm_df1$si_or_gt>10,]
summary(as.factor(ln_large_values$study))

######### now for shifted gamma (7.6% negative SI's) of He et al
##### he SI - fitted gamma with 7.6% negative serial intervals
#### got shape and rate and how they shifted distributions from github shared code : https://github.com/ehylau/COVID-19
df1 <- d[d$unique_id=="He et al. [35]",]
#### gamma shape
colnames(d)
he_g_sh <- d$central_value[d$variable=="parameter.1" &
                             d$unique_id=="He et al. [35]"]
he_g_sh
#### gamma rate 
he_g_r <- d$central_value[d$variable=="parameter.2" &
                            d$unique_id=="He et al. [35]"]
he_g_r
### sample distribution he SI
##### find value to subtract
##### what point is 7.6% into the distribution
qgammavalue <- qgamma(0.076, he_g_sh, he_g_r)
qgammavalue
he_si <- rgamma(n_sample, he_g_sh, he_g_r) - qgammavalue
hist(he_si)
plot(density(he_si), xlim=c(-5, 22))
summary(he_si)##### 
si_or_gt1 <- he_si ##### generate distribution for serial interval or generation time 
trs1 <- si_or_gt1-mca_ip #### subtract incubation period from serial interval or generation time to estimate transmission time relative to symptom onset
df2 <- data.frame(study=rep("He et al. [35]", n_sample)) ### collect data in a dataframe
df2$transmission_parameter <- rep("Serial Interval", n_sample)
df2$n_gt_or_si <- rep(unique(df1$n), n_sample)
df2$si_or_gt <- si_or_gt1
df2$trs <- trs1 
df2$si_or_gt_dist <- "shifted gamma (7.6% negative SI)"
df_he <- df2
df_he$n_gt_or_si <- rep(77, n_sample)

###### load three generation times (Ganyani Singapore, Ganyani Tianjin and Ferretti) and estimate SI
### Ganyani described how to do this in paper and code:
### https://www.eurosurveillance.org/content/10.2807/1560-7917.ES.2020.25.17.2000257
## ganyani singapore_base GT
##### singapore mean gt = 5.2, sd gt = 1.72
##### mean of ip = 5.2, sd = 2.8  from Zhang https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(20)30230-9/fulltext

ganyani_names <- c("Ganyani et al. [23a]", "Ganyani et al. [23c]")
ganyani_names1 <- c("Ganyani et al. [23b]", "Ganyani et al. [23d]")
ganyani_df1 <- data.frame()### make a dataframe to collect data from loop

for(i in 1:length(ganyani_names))
{
  df1 <- d[d$unique_id==ganyani_names[i],]  ### get data for a particular study
  g_mean <- df1$central_value[df1$variable=="Mean..95..CI...days."] 
  g_sd <- df1$central_value[df1$variable=="SD"] ### get gamma rate parameter for serial interval or generation time
  g_sh <- g_mean^2/(g_sd^2)
  g_r <- g_mean/(g_sd^2)
  gt1 <- rgamma(n_sample,g_sh, g_r)
  ###### Ganyani incubation period from Zhang https://www.thelancet.com/journals/laninf/article/PIIS1473-3099(20)30230-9/fulltext
  #####gamma shape=mean^2/sd^2  gamma rate=mean/sd^2
  inc1=rgamma(n_sample,shape=5.2^2/(2.8^2),rate = 5.2/(2.8^2))
  inc2=rgamma(n_sample,shape=5.2^2/(2.8^2),rate = 5.2/(2.8^2))
  si1 <- gt1 + inc1 - inc2
  ##### now estimate transmission time relative to symptoms from estimated Ganyani SI using same aproach as for other papers
  trs1 <- si1-mca_ip #### subtract incubation period from serial interval to estimate transmission time relative to symptom onset
  df2 <- data.frame(study=rep(ganyani_names1[i], n_sample)) ### collect data in a dataframe
  df2$transmission_parameter <- rep("Serial Interval", n_sample)
  df2$n_gt_or_si <- rep(unique(df1$number_of_infector_infectee_pairs), n_sample)
  df2$si_or_gt <- si1
  df2$trs <- trs1 
  df2$si_or_gt_dist <- "not directly reported - estimated from GT and IP"
  ganyani_df1<- rbind(ganyani_df1, df2)
  rm(df2)
}

summary(ganyani_df1)
########################################
##### merge dataframes
colnames(gamma_df1)
colnames(normal_df1)
colnames(weibull_df1)
colnames(lognorm_df1)
colnames(ganyani_df1)
colnames(df_he)

dfx <- rbind(gamma_df1, normal_df1, weibull_df1, lognorm_df1, ganyani_df1, df_he)
