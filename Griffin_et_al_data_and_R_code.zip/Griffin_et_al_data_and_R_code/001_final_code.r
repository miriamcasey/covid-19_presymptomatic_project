##### Aim: use extracted parameters from serial interval literature review to
#### simulate distributions and plot them as box plots.

#rm(list=ls())
library(tidyverse)
library(janitor)
library(epitrix)
library(fitdistrplus)
library(rriskDistributions)
library(mixdist)
library(ggplot2)

#### load data

d <- read_csv("long_data1.csv")
d <- clean_names(d)  #### make everything lower case for ease of coding
colnames(d)
summary(as.factor(d$unique_id))
length(unique(d$author))

###### take out the ones we cannot plot - for example because they do not fit a distribution
##### or because we cannot replicate their summary statistics - see Supplementary Table 1 in Griffin et al for 
#### reasons

summary(as.factor(d$ok_to_plot))

d <- d[d$ok_to_plot=="yes",]
summary(as.factor(d$unique_id))
length(unique(d$author))  #### 27 papers
length(unique(d$unique_id))  #### 33 serial interval estimates

summary(as.factor(d$distribution))  ##### see different distribution fitted
#################### some cross checking to make sure we are including all relevant extimates#############################################
wide_list <- read.csv("extracted_data_wide.csv")  #### read in wide data directly extracted for cross checking
jl <- as.character(unique(wide_list$Author[!is.na(wide_list$john_list)])) ### pull out unique author records for papers with multiple extimates
ml <- unique(d$author)  #### cross check with long data
length(ml)
setdiff(jl, ml) #### these three reported fitting distributions but we could not replicate them
setdiff(ml,jl)  #### zero
########################################################################

###### now simulate serial interval distributions (33 estimates from 27 papers)
###### the simulation code is "002_load_data_final.r"

### sample numbers
n_sample <- 100000  ####

#### load data and generate serial interval and transmission 
###   relative to symptom onset distributions.
source("002_load_data_final.r")

################# now prepare to plot Figure 2 boxplot in Griffin et al.
summary(dfx) #### dfx is the output from the simulation (code for this is 002_load_data_final.r)
colnames(dfx)
dfx$si_or_gt <- as.numeric(dfx$si_or_gt)
hist(dfx$si_or_gt)
summary(dfx$si_or_gt)
is.numeric(dfx$si_or_gt)
mean(dfx$si_or_gt)
dfx$study1 <- paste(dfx$study, dfx$transmission_parameter)
colnames(dfx)
##################### make a summary table for cross checking simulations against original summary statistics in papers
summary_table <- dfx  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
  group_by(study1) %>%
  summarise(n_samples=n(),
            n_si_less_than_0=sum(si_or_gt<0), #### negative serial intervals for relevant studies
            prop_neg_si=n_si_less_than_0/n_samples, ##### proportion negative serial intervals for relevant studies
            N_trs_neg=sum(trs<0), ### negative transmission time relative to symptom onset
            prop_trs_neg=N_trs_neg/n_samples, ### proportion negative transmission time relative to symptom onset
            trans_par_si_or_gt=unique(transmission_parameter),
            n_from_si_or_gt_study=unique(n_gt_or_si),
            dist_si_or_gt=unique(si_or_gt_dist), ### distribution of serial interval or generation time
            mean_si_or_gt=mean(si_or_gt),
            sd_si_or_gt=sd(si_or_gt),
            si_or_gt_2.5_percentile=quantile(si_or_gt, 0.025),
            si_or_gt_25_percentile=quantile(si_or_gt, 0.25),
            si_or_gt_median=quantile(si_or_gt, 0.5),
            si_or_gt_75_percentile=quantile(si_or_gt, 0.75),
            si_or_gt_97.5_percentile=quantile(si_or_gt, 0.975),
            mean_trs=mean(trs),
            sd_trs=sd(trs),
            trs_2.5_percentile=quantile(trs, 0.025),
            trs_25_percentile=quantile(trs, 0.25),
            median_trs=quantile(trs, 0.5),
            trs_75_percentile=quantile(trs, 0.75),
            trs_97.5_percentile=quantile(trs, 0.975))

colnames(dfx)

#write.csv(summary_table, "summary_table.csv")

################## boxplot
### order by median SI
######## clean up names for plot #################################################
dfx$transmission_parameter1 <- NA
summary(as.factor(dfx$transmission_parameter))
dfx$transmission_parameter1[grep("Gen", dfx$transmission_parameter)] <- "GT"
dfx$transmission_parameter1[grep("Ser", dfx$transmission_parameter)] <- "SI"
summary(as.factor(dfx$transmission_parameter1))
#######
refs <- read.csv("Griffin_et_al_ref_numbers_for_plot.csv")  ###### reference numbers for Griffin et al.
colnames(refs)
summary_table <- merge(summary_table, refs, by.x="study1", by.y="study1")
colnames(summary_table)
###### order by median transmission relative to symptom onset for plot
colnames(summary_table)
summary_table$Study <-fct_reorder(summary_table$ref, summary_table$si_or_gt_median, min)
summary_table$Study
colnames(dfx)
dfx1 <- merge(dfx, summary_table, by.x="study1", by.y="study1")

summary_table$transmission_parameter1 <- NA

summary_table$transmission_parameter1[grep("Gen", summary_table$trans_par_si_or_gt)] <- "GT"
summary_table$transmission_parameter1[grep("Generation", summary_table$study1)] <- "GT"
summary_table$transmission_parameter1[grep("Ser", summary_table$trans_par_si_or_gt)] <- "SI"
summary(as.factor(summary_table$transmission_parameter1))

###################################finished cleaning up names for plot#########################
############################Plot transmission time relative to symptom onset
colnames(dfx1)

p <- ggplot(dfx1, aes(x=Study, y=si_or_gt)) + 
  geom_boxplot(outlier.shape=NA) 
p
p <- p + coord_flip() + ylim(-13, 20)
p
p <- p+ ylab("Days")
p <- p + geom_hline(yintercept=0, col="red")
colnames(summary_table)
p <- p + geom_point( data=summary_table,
                     aes(x=Study, y=mean_si_or_gt), col="purple", shape=17, size=6)
p
p <- p+ facet_grid(vars(rows=transmission_parameter1),scales="free", space="free", drop=TRUE)
p
p <- p+ theme(panel.spacing = unit(5, "lines"))

###### PDF for paper

#theme_for_font <- 
  #theme(
  #  axis.title.y = element_text(face="bold", size=40),
   # axis.title.x = element_text(face="bold", size=40),
   # axis.text.x  = element_text( vjust=0.5, size=30, color="black"),
    #axis.text.y  = element_text(size=30, color="black"),
    #plot.title = element_text(family = "Helvetica", face = "bold", size = (40)
    #)) 

#strip_text_theme <-  theme(strip.text.y = element_text(size=60, face="bold"))
#p + theme_for_font  +  strip_text_theme
#p1 <- p + theme_for_font

  
#pdf("Figure_2.pdf", width=20, height=28)
 #p   + theme_for_font  + strip_text_theme
#dev.off()
            





