##### PLEASE NOTE YOU WILL NEED TOP SET WORKING DIRECTORIES FOR THIS CODE TO RUN
########## Aim: for the papers which we could not simulate distributions
######### use extracted serial interval data underlying papers to
######## generate ridge plots for Griffin et al (Supplementary Figures 1 and 2)
####### we could not simulate distributions for 13 of the 40 papers in teh review
##### please see supplementary table 1 in Griffin et al to see bgreakdown of these
library(tidyverse)
library(ggplot2)
library(ggridges)
########## Please set working directory to where raw SI data are
setwd("~/Documents/covid_19/revisions/revised_paper/plots_for_john/Griffin_et_al_data_and_R_code/raw_SI_values")
###### load extracted serial interval data

ki_si_values <- c(12,3,4,4,3,4,9,15,13) 
ki_ref <- "Ki et al. [26]"
ki_ref1 <- "[26]"
ki_data <- "not_same_as_stats_in_paper"  #### we could not replicate summary statistics in the paper
ki_df <- data.frame(si_values=ki_si_values)
ki_df$ref <- rep(ki_ref, length(ki_si_values))
ki_df$ref1 <- rep(ki_ref1, length(ki_si_values))
ki_df$data_comment <- rep(ki_data, length(ki_si_values))


bao <- read.csv("Bao_et_al_2020_raw_SI_values.csv")
bao_si_values <- bao$Serial.interval.value
bao_ref <- "Bao et al. [16]"
bao_ref1 <- "[16]"
bao_data <- "not_same_as_stats_in_paper"

bao_df <- data.frame(si_values=bao_si_values)
bao_df$ref <- rep(bao_ref, length(bao_si_values))
bao_df$ref1 <- rep(bao_ref1, length(bao_si_values))
bao_df$data_comment <- rep(bao_data, length(bao_si_values))

huang_si_values <- c(4,2,0,3,1,1,0)
huang_ref <- "Huang et al. [27]"
huang_ref1 <- "[27]"
huang_data <- "same_as_paper"
huang_df <- data.frame(si_values=huang_si_values)
huang_df$ref <- rep(huang_ref, length(huang_si_values))
huang_df$ref1 <- rep(huang_ref1, length(huang_si_values))
huang_df$data_comment <- rep(huang_data, length(huang_si_values))

pung_si_values <- c(3, 4, 8)
pung_ref <- "Pung et al [28]"
pung_ref1 <- "[28]"
pung_data <- "same_as_paper"
pung_df <- data.frame(si_values=pung_si_values)
pung_df$ref <- rep(pung_ref, length(pung_si_values))
pung_df$ref1 <- rep(pung_ref1, length(pung_si_values))
pung_df$data_comment <- rep(pung_data, length(pung_si_values))


boehmer_si_values <- c(2,0,4,3,5,4,4,2,6,5,7)
boehmer_ref <- "Bohmer et al [3]"
boehmer_ref1 <- "[3]"
boehmer_data <-  "same_as_paper"
boehmer_df <- data.frame(si_values=boehmer_si_values)
boehmer_df$ref <- rep(boehmer_ref, length(boehmer_si_values))
boehmer_df$ref1 <- rep(boehmer_ref1, length(boehmer_si_values))
boehmer_df$data_comment <- rep(boehmer_data, length(boehmer_si_values))


liao <- read.csv("Liao_et_al_2020_raw_SI_values.csv")
liao_si_values <- liao$serial_interval
liao_ref <- "Liao et al. [34]"
liao_ref1 <- "[34]"
liao_data <- "not_same_as_stats_in_paper"
liao_df <- data.frame(si_values=liao_si_values)
liao_df$ref <- rep(liao_ref, length(liao_si_values))
liao_df$ref1 <- rep(liao_ref1, length(liao_si_values))
liao_df$data_comment <- rep(liao_data, length(liao_si_values))

mettler <- read.csv("mettler_data.csv")
mettler_si_values <- mettler$serial_interval
mettler_ref <- "Mettler et al. [40]"
mettler_ref1 <- "[40]"
mettler_data <- "same_as_paper"
mettler_df <- data.frame(si_values=mettler_si_values)
mettler_df$ref <- rep(mettler_ref, length(mettler_si_values))
mettler_df$ref1 <- rep(mettler_ref1, length(mettler_si_values))
mettler_df$data_comment <- rep(mettler_data, length(mettler_si_values))

wang <- read.csv("Wang_et_al_2020d_raw_SI_values.csv")
colnames(wang)
wang_si_values <- rep(wang$Day, wang$count)
summary(wang_si_values)
wang_ref <- "Wang et al. [9]"
wang_ref1 <- "[9]"
wang_data <- "same_as_paper"
wang_df <- data.frame(si_values=wang_si_values)
wang_df$ref <- rep(wang_ref, length(wang_si_values))
wang_df$ref1 <- rep(wang_ref1, length(wang_si_values))
wang_df$data_comment <- rep(wang_data, length(wang_si_values))


chun <- read.csv("chun_raw_si_values.csv")
summary(chun)
chun_si_values <- chun$raw_si
chun_ref <- "Chun et al. [39]"
chun_ref1 <- "[39]"
chun_data <- "not_same_as_stats_in_paper"
chun_df <- data.frame(si_values=chun_si_values)
chun_df$ref <- rep(chun_ref, length(chun_si_values))
chun_df$ref1 <- rep(chun_ref1, length(chun_si_values))
chun_df$data_comment <- rep(chun_data, length(chun_si_values))


zhao <- read.csv("zhao_mid_sis.csv")
zhao_si_values <- zhao$mid.SI
summary(zhao_si_values)
zhao_ref <- "Zhao et al. [32]"
zhao_ref1 <- "[32]"
zhao_data <- "same_as_paper"
zhao_df <- data.frame(si_values=zhao_si_values)
zhao_df$ref <- rep(zhao_ref, length(zhao_si_values))
zhao_df$ref1 <- rep(zhao_ref1, length(zhao_si_values))
zhao_df$data_comment <- rep(zhao_data, length(zhao_si_values))

combined <- rbind(ki_df, bao_df, huang_df, 
                  pung_df, boehmer_df, liao_df,
                  mettler_df, wang_df, chun_df,
                  zhao_df)

colnames(combined)  ##### all extracted data together

#####################################
######## trial ridge plot
ggplot(combined, aes(x = si_values, y = ref1)) + geom_density_ridges()

##################################

####### both of those worked ok so now merge with main dataset
###### please set working directory
setwd("~/Documents/covid_19/revisions/revised_paper/plots_for_john/Griffin_et_al_data_and_R_code")
source("001_final_code.r")
refs <- read.csv("Griffin_et_al_ref_numbers_for_plot.csv")
colnames(dfx)
  colnames(refs)
head(refs)
head(dfx)
dfx <- merge(dfx, refs, by.x="study1", by.y="study1")
########## merge these
colnames(dfx)
colnames(combined)
combined$transmission_parameter1 <- "SI"
dfx$si_values <- dfx$si_or_gt
dfx$ref1 <- dfx$ref
dfx$ref <- dfx$study
dfx$data_comment <- "from_simulation"
cnw <- intersect(colnames(dfx), colnames(combined))
dfx2 <- dfx[,cnw]
dfx3 <- rbind(dfx2, combined)

#################################################################
######### now make a new summary table and plot again
colnames(dfx3)
summary(dfx3)
dfx3[is.na(dfx3$si_values),]
dfx3 <- dfx3[!is.na(dfx3$si_values),]
summary_table1 <- dfx3  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
  group_by(ref, ref1, data_comment, transmission_parameter1) %>%
  summarise(n_samples=n(),
            mean=mean(si_values),
            sd=sd(si_values),
            min=min(si_values),
            max=max(si_values),
            si_values_2.5_percentile=quantile(si_values, 0.025),
            si_values_25_percentile=quantile(si_values, 0.25),
            si_values_median=quantile(si_values, 0.5),
            si_values_75_percentile=quantile(si_values, 0.75),
            si_values_97.5_percentile=quantile(si_values, 0.975))
            
#write.csv(summary_table1, "summary_table_including_non_distribution_papers_for_cross_check.csv")  

################# order references by median
colnames(dfx3)
colnames(summary_table1)
cn <- intersect(colnames(dfx3), colnames(summary_table1))
dfx4 <- merge(dfx3, summary_table1, by.x=cn, by.y=cn)
dfx4$Study <-fct_reorder(dfx4$ref1, dfx4$si_values_median, min)
summary_table1$Study <-fct_reorder(summary_table1$ref1, summary_table1$si_values_median, min)

colnames(dfx4)

dfx4[dfx4$ref1=="[26]",]  #### review ki et al

summary(ki_si_values)
boxplot(ki_si_values)
hist(ki_si_values)


dfx4$data_source <- NA
summary(as.factor(dfx4$data_comment))
dfx4$data_source[dfx4$data_comment=="from_simulation"] <- "From simulation"
dfx4$data_source[dfx4$data_comment!="from_simulation"] <- "From data"

colnames(summary_table1)
summary_table$data_source <- NA
summary_table1$data_source[summary_table1$data_comment=="from_simulation"] <- "From simulation"
summary_table1$data_source[summary_table1$data_comment!="from_simulation"] <- "From data"

####################################################################
################# boxplot all
colnames(summary_table1)
p <- ggplot(dfx4, aes(x=Study, y=si_values, fill=data_source)) + 
  geom_boxplot(outlier.shape=NA) 
p <- p + scale_fill_manual(values=c( "grey", "white"))
p <- p + theme(legend.position = "none")

p
p <- p + coord_flip() + ylim(-13, 20)
p
p <- p+ ylab("Days")
p <- p + geom_hline(yintercept=0, col="red")
colnames(summary_table)
p <- p + geom_point(data=summary_table1,
                     aes(x=Study, y=mean), col="purple", shape=17, size=6)
p
p <- p+ facet_grid(vars(rows=transmission_parameter1),scales="free", space="free", drop=TRUE)
p
p <- p+ theme(panel.spacing = unit(5, "lines"))
p

#########################################################
######### ridgeplot all - summplemntary figure 2 in Griffin et al.
#rm(p)
p <- ggplot(dfx4, 
            aes(y=Study, x=si_values, fill=data_source)) + 
  geom_density_ridges()
p <- p + scale_fill_manual(values=c("grey", "white"))

p <- p + theme(legend.position = "none")

#p <- p + coord_flip() + ylim(-13, 20)
p
p <- p+ xlab("Days") + xlim(-5, 20) + ylab("Study")
p
p <- p+ facet_grid(vars(rows=transmission_parameter1),scales="free", space="free", drop=TRUE)
p
p <- p+ theme(panel.spacing = unit(5, "lines"))
p

###### PDF

#theme_for_font <- 
 # theme(
 #   axis.title.y = element_text(face="bold", size=40),
  #  axis.title.x = element_text(face="bold", size=40),
  #  axis.text.x  = element_text( vjust=0.5, size=30, color="black"),
   # axis.text.y  = element_text(size=30, color="black"),
  #  plot.title = element_text(family = "Helvetica", face = "bold", size = (40)
  #  )) 

#strip_text_theme <-  theme(strip.text.y = element_text(size=60, face="bold"))
#p + theme_for_font  +  strip_text_theme
#p1 <- p + theme_for_font


#pdf("Supplementary_figure2.pdf", width=20, height=28)
#p   + theme_for_font  + strip_text_theme
#dev.off()
#getwd()

#############################################################
################# now again only including data that matched summary statistics
######### ridgeplot paper summary statistic matches only : Supplementary figure 1
summary(as.factor(dfx4$data_comment))
dfx5 <- dfx4[dfx4$data_comment!="not_same_as_stats_in_paper",]
summary(as.factor(dfx5$ref))
#rm(p)
p <- ggplot(dfx5, 
            aes(y=Study, x=si_values, fill=data_source)) + 
  geom_density_ridges()
p <- p + scale_fill_manual(values=c("grey", "white"))

p <- p + theme(legend.position = "none")

#p <- p + coord_flip() + ylim(-13, 20)
p
p <- p+ xlab("Days") + xlim(-5, 20) + ylab("Study")
p
p <- p+ facet_grid(vars(rows=transmission_parameter1),scales="free", space="free", drop=TRUE)
p
p <- p+ theme(panel.spacing = unit(5, "lines"))
p


#pdf("Supplementary_figure1.pdf", width=20, height=28)
#p   + theme_for_font  + strip_text_theme
#dev.off()



