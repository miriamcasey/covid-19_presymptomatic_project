####### summarise results of simulation incorporating uncertainty

path_out = "~/Documents/covid_19/revisions/revised_paper/plots_for_john/SARS_CoV-2_presym_data_and_code/Sim_A_output1" ##### for saving results
setwd(path_out)
sim_b_si <- read.csv("si_df.csv")  ###### si from bootstrapping
sim_b_trs <- read.csv("trs_df.csv")  ####### trs from bootstrapping

##################################################################################################
######### first : read in and summarise full simulation to get means
### make a loop to read all csv files reporting TRS samples from Simulation A output
options(scipen = 999)
setwd("~/Documents/covid_19/revisions/revised_paper/plots_for_john/SARS_CoV-2_presym_data_and_code/Sim_A_output1")

trs_files <- list.files()
trs_files
one <- trs_files[grep("TRS", trs_files)]
two <- trs_files[grep("strap_TRS", trs_files)]
one
two
three <- setdiff(one, two)
three
trs_files <- three
trs_sim_output <- data.frame()
trs_sim_output1 <- data.frame()
for (i in 1:length(trs_files))
{
  x <- read_csv(trs_files[i])
  colnames(x)
  trs_sim_output <- rbind(trs_sim_output, x)
  x1 <- x[!is.na(x$TRS),]
  trs_sim_output1 <- rbind(trs_sim_output1, x1)
}

############ summarise full simulation output

summary_table_sim <- trs_sim_output1  %>%
  group_by(study) %>%
  summarise(n_samples=n(),
            N_trs_neg=sum(TRS<0, na.rm=T), ### negative transmission time relative to symptom onset
            prop_trs_neg=N_trs_neg/n_samples, ### proportion negative transmission time relative to symptom onset### distribution of serial interval or generation time
            mean_trs=mean(TRS, na.rm=T),
            sd_trs=sd(TRS, na.rm=T),
            trs_2.5_percentile=quantile(TRS, 0.025, na.rm=T),
            trs_25_percentile=quantile(TRS, 0.25, na.rm=T),
            median_trs=quantile(TRS, 0.5, na.rm=T),
            trs_75_percentile=quantile(TRS, 0.75, na.rm=T),
            trs_97.5_percentile=quantile(TRS, 0.975, na.rm=T))

####### merge with bootstrapping summary table for 1: comparison of full sim and bootstrapping means 

colnames(summary_table_sim)

########## merge bs2 (bootstrapping output) with summary_table_sim (full simulation output)################
colnames(summary_table_sim)
melt_sim_summary <- melt(summary_table_sim, id.vars=c("study","n_samples"))
simsum <- as.character(unique(melt_sim_summary$variable))
colnames(sim_b_trs)
bs <- as.character(unique(sim_b_trs$variable))
bs <- bs[bs!="n_samples"]
length(simsum)
length(bs)
cbind(simsum, bs)
bs
bs1 <- c("n_trs_neg" , "prop_trs_neg" , "meanx" , "sdx"  , "X2.5" ,"X25"  ,             
 "X50"      ,          "X75"    ,            "X97.5")
length(simsum)
length(bs1)
trans <- cbind(simsum, bs1)
trans
sim_b_trs1 <- merge(sim_b_trs, trans, by.x="variable", by.y="bs1")

sim_bs_merge <- merge(melt_sim_summary, sim_b_trs1, by.x=c("study","variable"),
                      by.y=c("study", "simsum"))

props <- sim_bs_merge[sim_bs_merge$variable=="prop_trs_neg",]
head(props)
props1 <- props
props1$value <- props$value*100
props1[,8:11]<- props[,8:11]*100
props1$variable <- "percentage_trs_neg"

sim_bs_merge1 <- rbind(sim_bs_merge, props1)
sim_bs_merge1$value <- round(sim_bs_merge1$value, digits=1)
sim_bs_merge1[,8:11] <- round(sim_bs_merge1[,8:11], digits=1)

####### see difference in simulation mean and bootstrapping mean
colnames(sim_bs_merge1)
sim_bs_merge1$diff_means <- sim_bs_merge1$value - sim_bs_merge1$meanx
plot(sim_bs_merge1$diff_means[sim_bs_merge1$variable!="N_trs_neg"])
summary(sim_bs_merge1$diff_means[sim_bs_merge1$variable!="N_trs_neg"]) #### v little difference
##### format for presentation on a table
colnames(sim_bs_merge1)
unique(sim_bs_merge1$variable)
sim_bs_merge2 <- sim_bs_merge1[sim_bs_merge1$variable!="N_trs_neg" &
                                 sim_bs_merge1$variable!="prop_trs_neg", ]
sim_bs_merge2$text <- paste(sim_bs_merge2$value, " (",  sim_bs_merge2$lci,
                            ", ", sim_bs_merge2$uci, ")", sep=""
                            )

table_for_paper <- dcast(sim_bs_merge2, study~variable, value.var="text")
