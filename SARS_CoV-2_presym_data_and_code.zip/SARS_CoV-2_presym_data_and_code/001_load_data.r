##### Load data and run basic simulation (for supplementary materials)
##### and simulation incorporating uncertainty (for main paper)

setwd("~/Documents/covid_19/revisions/revised_paper/plots_for_john/SARS_CoV-2_presym_data_and_code")
#rm(list=ls())
library(tidyverse)
library(janitor)
library(epitrix)
library(fitdistrplus)
library(rriskDistributions)
library(mixdist)
library(ggplot2)
library(reshape2)
library(mixdist)
library(kableExtra)

#### load data

d <- read_csv("long_data1.csv")
d <- clean_names(d)  #### make everything lower case for ease of coding
colnames(d)
summary(as.factor(d$unique_id))
length(unique(d$author))
d <- d[d$ok_to_plot=="yes",]  ### remove any papers from which we could not replicate serial interval or generation time distributions
colnames(d)
length(unique(d$author))
length(unique(d$unique_id))

d1 <- read.csv("d5_for_inputs1.csv") 
d1 <- clean_names(d1) 
d1x <- d1[,c("unique_id", "country")] ### required columns for this code
#### d1 contains cleaned country and region and added information about presymptomatic transmission
d <- merge(d, d1x, by.x="unique_id", by.y="unique_id")

d$distribution[d$author=="Chun et al. [39]"] <- "shifted lognormal"  ### this onse needs separate consideration in simulation due to shift parameter of 3.1 days
summary(as.factor(d$distribution))  ##### see different distribution fitted

####### remove estimates from mixed countries - we are excluding these from the study
###### now exclude 4 papers, five estimates with mixed countries
unique(d$country)
unique(d$unique_id[d$country=="Combination"])
d <- d[d$country!="Combination",]
length(unique(d$author))
length(unique(d$unique_id))

##### remove ganyani serial intervals - we are only using the generation times to avoid duplication

dd <- d[d$unique_id!="Ganyani et al. [23b]" & d$unique_id!="Ganyani et al. [23d]",]

###### basic simulation without taking uncertainty into account
###### the simulation code is "002_basic_simulation.r"

### sample numbers
n_sample <- 100000  ####

#### load data and generate serial interval and transmission 
###   relative to symptom onset distributions.
source("002_basic_simulation.r")

########## summarise basic simulation output for supplementary materials

summary(dfx) ####  output from simulation

##################### make a summary table for cross checking simulations against original summary statistics in papers
summary_table <- dfx  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
  group_by(study) %>%
  summarise(n_samples=n(),
            n_si_less_than_0=sum(si_or_gt<0), #### negative serial intervals for relevant studies
            prop_neg_si=n_si_less_than_0/n_samples, ##### proportion negative serial intervals for relevant studies
            N_trs_neg=sum(trs<0), ### negative transmission time relative to symptom onset
            prop_trs_neg=N_trs_neg/n_samples, ### proportion negative transmission time relative to symptom onset
            trans_par_si_or_gt=unique(transmission_parameter),
            n_from_si_or_gt_study=unique(n_gt_or_si),
            dist_si_or_gt=unique(si_or_gt_dist), ### distribution of serial interval or generation time
            mean_si_or_gt=mean(si_or_gt),
            sd_si_or_gt=sd(si_or_gt),
            si_or_gt_2.5_percentile=quantile(si_or_gt, 0.025),
            si_or_gt_25_percentile=quantile(si_or_gt, 0.25),
            si_or_gt_median=quantile(si_or_gt, 0.5),
            si_or_gt_75_percentile=quantile(si_or_gt, 0.75),
            si_or_gt_97.5_percentile=quantile(si_or_gt, 0.975),
            mean_trs=mean(trs),
            sd_trs=sd(trs),
            trs_2.5_percentile=quantile(trs, 0.025),
            trs_25_percentile=quantile(trs, 0.25),
            median_trs=quantile(trs, 0.5),
            trs_75_percentile=quantile(trs, 0.75),
            trs_97.5_percentile=quantile(trs, 0.975))

colnames(dfx)

colnames(summary_table)
summary_table$percent_neg_si <- summary_table$prop_neg_si*100
summary_table$percent_neg_trs <- summary_table$prop_trs_neg*100
summary_table[,10:ncol(summary_table)] <- round(summary_table[,10:ncol(summary_table)] , digits=1)


#####################################################################################
########### now, the simulation incorporating uncertainty that is presented in the main paper

efsa <- read_csv("enough_for_sim_A.csv")  ### estimates that report enough information to capture uncertaintuy

d <- merge(d, efsa, by.x="unique_id", by.y="enough_for_simA")

length(unique(d$unique_id))

#source("003_simulation_with_uncertainty.r") ##### this takes about an hour to run on a standard laptop.


















