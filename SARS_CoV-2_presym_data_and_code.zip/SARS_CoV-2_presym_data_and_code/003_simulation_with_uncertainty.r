#### taking uncertainty into account: Simulation A
########### I have collected simulation outputs in particular folders to make it easier to summarise them later
############ If rerunning/testing code, the same will need to be done - that is replace my folders with your own
######### one file for serial interval or generation time outputs setwd("~/Documents/covid_19/r_files/SARS_CoV-2_presym_data_and_code/sim_b_output/si")
######## one file for transmission time relative to symptom onset outputs setwd("~/Documents/covid_19/r_files/SARS_CoV-2_presym_data_and_code/sim_b_output/trs")
##### one file for bootstrapping output for transmission time relative to symptom output: setwd("~/Documents/covid_19/r_files/SARS_CoV-2_presym_data_and_code/sim_b_output/strap_trs")
###### summary csv file for serial interval/generation time bootstrap summary stats: "si_df.csv"
###### summary csv file for transmission time relative to symptom onset bootstrap summary stats: "trs_df.csv"

###### make an output file

path_out = "~/Documents/covid_19/revisions/revised_paper/plots_for_john/SARS_CoV-2_presym_data_and_code/Sim_A_output2"

colnames(d)

n_primary_runs <-  1000  ####1000
n_primary_samples <- 1000 ####1000
n_bootstrap_runs <- 10000  #####10000
n_bootstrap_samples <- 1000 ##### 1000

### load data and estimate transmission time relative to symptoms

#### load incubation period from McAloon et al metanalysis:   

##### mu and sigma parameters (95% CIs) of 1.63 (95% CI 1.51 to 1.75) 
####   and 0.50 (95% CI 0.46 to 0.55), respectively. The corresponding 
##### mean (95% CIs) was 5.8 (95% CI 5.0 to 6.7) days.

mca_ip_ml <- 1.63
mca_ip_ml_lci <- 1.51
mca_ip_ml_uci <- 1.75
mca_ip_sdl <- 0.50 
mca_ip_sdl_lci <- 0.46
mca_ip_sdl_uci <- 0.55

sims <- data.frame (IP=numeric())
for (y in 1:n_primary_runs){
  mu = rnorm(1, mca_ip_ml, (mca_ip_ml_uci-mca_ip_ml_lci)/(2*1.96))
  sigma = rnorm(1, mca_ip_sdl, (mca_ip_sdl_uci-mca_ip_sdl_lci)/(2*1.96))
  A=data.frame(IP=rlnorm(n_primary_samples, mu, sigma))
  sims=bind_rows(sims, A)
}
summary(sims)
sd(sims$IP)
write.csv(sims, file.path(path_out, "IP_simB.csv"))

###### make some dataframes to collect simulation A output

collection_si <- data.frame()
collection_trs <- data.frame()

#######################################gamma distributions############################################################
#### make loop for gamma distributed serial intervals / generation times with ci's for mean and standard deviation
colnames(d)
summary(as.factor(d$distribution))
gamma_df <- d[d$distribution=="gamma",]  #### all gammas supply mean and sd
gamma_names <- unique(gamma_df$unique_id)
gamma_names

colnames(d)
unique(d$variable)
for(i in 1:length(gamma_names))
{
  df1 <- d[d$unique_id==gamma_names[i],]  ### get data for a particular study
  mean_data <- df1$central_value[df1$variable=="Mean..95..CI...days."] 
  mean_data_lci <-  df1$lower_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  mean_data_uci <-  df1$upper_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  sd_data<- df1$central_value[df1$variable=="SD"]
  sd_data_lci <- df1$lower_confidence_interval[df1$variable=="SD"]
  sd_data_uci <- df1$upper_confidence_interval[df1$variable=="SD"]
  
  sims1 <- data.frame ()
  for (j in 1:n_primary_runs){
    meanx <- rnorm(1, mean_data, (mean_data_uci-mean_data_lci)/(2*1.96))
    
    #######  gamma distribution for standard deviation
    #####gamma shape=mean^2/sd^2  gamma rate=mean/sd^2
    sd_sd <- (sd_data_uci-sd_data_lci)/(2*1.96)
    sd_mean <- sd_data
    sd_shape <- sd_mean^2/(sd_sd^2)
    sd_rate <- sd_mean/(sd_sd^2)
    sdx <- rgamma(1, sd_shape, sd_rate)
    #####gamma shape=mean^2/sd^2  gamma rate=mean/sd^2
    shapex <- meanx^2/(sdx^2)
    ratex <- meanx/(sdx^2)
    B=data.frame(SI=rgamma(n_primary_samples, shapex, ratex))
    summary(B)
    sims1 <- rbind(sims1, B)
  }
  summary(sims1)
  sims1x <- as.data.frame(sims1)
  sims1x$study <- gamma_names[i]
  name_csv <- paste("SI", gamma_names[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims1x, file.path(path_out, name_csv))

  strap_si <- data.frame()
  for(k in 1:n_bootstrap_runs){
    a <- sample_n(sims1, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(mean=mean(a$SI, na.rm=T), 
                    sd=sd(a$SI, na.rm=T),
                    X2.5=quantile(a$SI, probs=0.025, na.rm=T),
                    X25=quantile(a$SI, probs=0.25, na.rm=T),
                    X50=quantile(a$SI, probs=0.5, na.rm=T),
                    X75=quantile(a$SI, probs=0.75, na.rm=T),
                    X97.5=quantile(a$SI, probs=0.975, na.rm=T),
                    n_samples=length(a$SI[!is.na(a$SI)]),
                    n_SI_neg=sum(a$SI<0, na.rm=T))
    Ax$prop_SI_neg <- Ax$n_SI_neg/Ax$n_samples
    strap_si=bind_rows(strap_si, Ax)
  }
  
  melt_strap_si <- melt(strap_si)
  summary_table_si <- melt_strap_si  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  gamma_names[i]
  summary_table_si$study <- gamma_names[i]
  collection_si <- rbind(collection_si, summary_table_si)
  ######## transmission relative to symptom onset plus bootstrap
  TRS <- sims1$SI-sims$IP
  sims2 <- data.frame(TRS=TRS)
  sims2x <- as.data.frame(sims2)
  sims2x$study <- gamma_names[i]
  name_csv <- paste("TRS", gamma_names[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims2x, file.path(path_out, name_csv))

  sum(TRS<0, na.rm=T)
  length(a$TRS)
  length(a$TRS[!is.na(a$TRS)])
  strap_trs <- data.frame()
  
  for(l in 1:n_bootstrap_runs){
    a <- sample_n(sims2, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(meanx=mean(a$TRS, na.rm=T), 
                    sdx=sd(a$TRS, na.rm=T),
                    X2.5=quantile(a$TRS, probs=0.025, na.rm=T),
                    X25=quantile(a$TRS, probs=0.25, na.rm=T),
                    X50=quantile(a$TRS, probs=0.5, na.rm=T),
                    X75=quantile(a$TRS, probs=0.75, na.rm=T),
                    X97.5=quantile(a$TRS, probs=0.975, na.rm=T),
                    n_samples=length(a$TRS[!is.na(a$TRS)]),
                    n_trs_neg=sum(a$TRS<0, na.rm=T))
    Ax$prop_trs_neg <- Ax$n_trs_neg/Ax$n_samples
    strap_trs=bind_rows(strap_trs, Ax)
  }
  ###### save strap trs
  name_csv <- paste("strap_TRS", gamma_names[i], i, ".csv", sep="_")
  name_csv
  write.csv(strap_trs, file.path(path_out, name_csv))

  melt_strap_trs <- melt(strap_trs)
  summary_table_trs <- melt_strap_trs  %>%  
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  summary_table_trs$study <- gamma_names[i]
  
  collection_trs <- rbind(collection_trs, summary_table_trs)
  
}
summary(sims1x)
summary(sims2x)
#######################################################################################################################
##############################################normal distributions#########################################################
#######

df_norm_mean_sd <- d[d$distribution=="normal",]
names_df_norm_mean_sd <- unique(df_norm_mean_sd$unique_id)
names_df_norm_mean_sd
collection_si1 <- data.frame()
collection_trs1 <- data.frame()

for (i in 1:length(names_df_norm_mean_sd))
{
  df1 <- d[d$unique_id==names_df_norm_mean_sd[i],]
  colnames(df1)
  mean_data <- df1$central_value[df1$variable=="Mean..95..CI...days."] 
  mean_data_lci <-  df1$lower_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  mean_data_uci <-  df1$upper_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  sd_data<- df1$central_value[df1$variable=="SD"]
  sd_data_lci <- df1$lower_confidence_interval[df1$variable=="SD"]
  sd_data_uci <- df1$upper_confidence_interval[df1$variable=="SD"]
  sims1 <- data.frame ()
  for (j in 1:n_primary_runs){
    meanx <- rnorm(1, mean_data, (mean_data_uci-mean_data_lci)/2*1.96)
    ####### try gamma distribution for standard deviation
    #####gamma shape=mean^2/sd^2  gamma rate=mean/sd^2
    sd_sd <- (sd_data_uci-sd_data_lci)/(2*1.96)
    sd_mean <- sd_data
    sd_shape <- sd_mean^2/(sd_sd^2)
    sd_rate <- sd_mean/(sd_sd^2)
    sdx <- rgamma(1, sd_shape, sd_rate)
    B=data.frame(SI=rnorm(n_primary_samples, meanx, sdx))
    summary(B)
    sims1 <- rbind(sims1, B)
  }
  summary(sims1)
  sims1x <- as.data.frame(sims1)
  sims1x$study <- names_df_norm_mean_sd[i]
  name_csv <- paste("SI", names_df_norm_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims1x, file.path(path_out, name_csv))
  
  strap_si <- data.frame()
  for(k in 1:n_bootstrap_runs){
    a <- sample_n(sims1, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(mean=mean(a$SI, na.rm=T), 
                    sd=sd(a$SI, na.rm=T),
                    X2.5=quantile(a$SI, probs=0.025, na.rm=T),
                    X25=quantile(a$SI, probs=0.25, na.rm=T),
                    X50=quantile(a$SI, probs=0.5, na.rm=T),
                    X75=quantile(a$SI, probs=0.75, na.rm=T),
                    X97.5=quantile(a$SI, probs=0.975, na.rm=T),
                    n_samples=length(a$SI[!is.na(a$SI)]),
                    n_SI_neg=sum(a$SI<0, na.rm=T))
    Ax$prop_SI_neg <- Ax$n_SI_neg/Ax$n_samples
    strap_si=bind_rows(strap_si, Ax)
  }
  
  melt_strap_si <- melt(strap_si)
  summary_table_si <- melt_strap_si  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  names_df_norm_mean_sd[i]
  summary_table_si$study <- names_df_norm_mean_sd[i]
  collection_si1 <- rbind(collection_si1, summary_table_si)
  ######## transmission relative to symptoms plus bootstrap
  TRS <- sims1$SI-sims$IP
  sims2 <- data.frame(TRS=TRS)
  sims2x <- as.data.frame(sims2)
  sims2x$study <- names_df_norm_mean_sd[i]
  name_csv <- paste("TRS", names_df_norm_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims2x, file.path(path_out, name_csv))
  sum(TRS<0, na.rm=T)
  length(TRS[!is.na(TRS)])
  strap_trs <- data.frame()
  
  for(l in 1:n_bootstrap_runs){
    a <- sample_n(sims2, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(meanx=mean(a$TRS, na.rm=T), 
                    sdx=sd(a$TRS, na.rm=T),
                    X2.5=quantile(a$TRS, probs=0.025, na.rm=T),
                    X25=quantile(a$TRS, probs=0.25, na.rm=T),
                    X50=quantile(a$TRS, probs=0.5, na.rm=T),
                    X75=quantile(a$TRS, probs=0.75, na.rm=T),
                    X97.5=quantile(a$TRS, probs=0.975, na.rm=T),
                    n_samples=length(a$TRS[!is.na(a$TRS)]),
                    n_trs_neg=sum(a$TRS<0, na.rm=T))
    Ax$prop_trs_neg <- Ax$n_trs_neg/Ax$n_samples
    strap_trs=bind_rows(strap_trs, Ax)
  }
  ###### save strap trs
  name_csv <- paste("strap_TRS", names_df_norm_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(strap_trs, file.path(path_out, name_csv))
  
  melt_strap_trs <- melt(strap_trs)
  summary_table_trs <- melt_strap_trs  %>%  
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  summary_table_trs$study <- names_df_norm_mean_sd[i]
  
  collection_trs1 <- rbind(collection_trs1, summary_table_trs)
  
}

#####################################################################################################################
####################################lognormal distribution
###### lognormal distribution with mean and standard deviation
#sigma <- sqrt(log(v/(mean^2)+1))
#mu <- log(mean) - (sigma)^2/2

####### mean_sd_lognormal - Kwok has mean and sd wu has lognormal parameters

df_lnorm_mean_sd <- d[d$distribution=="lognormal" & d$unique_id!="Wu et al. [14]" ,]
names_df_lnorm_mean_sd <- unique(df_lnorm_mean_sd$unique_id)
names_df_lnorm_mean_sd
collection_si2 <- data.frame()
collection_trs2 <- data.frame()

for (i in 1:length(names_df_lnorm_mean_sd))
{
  df1 <- d[d$unique_id==names_df_lnorm_mean_sd[i],]
  mean_data <- df1$central_value[df1$variable=="Mean..95..CI...days."] 
  mean_data_lci <-  df1$lower_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  mean_data_uci <-  df1$upper_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  sd_data<- df1$central_value[df1$variable=="SD"]
  sd_data_lci <- df1$lower_confidence_interval[df1$variable=="SD"]
  sd_data_uci <- df1$upper_confidence_interval[df1$variable=="SD"]
  
  sims1 <- data.frame ()
  for (j in 1:n_primary_runs){
    ####### mean of lognormal distribution is non negative so use gamma distribution
    mean_sd <- (mean_data_uci-mean_data_lci)/(2*1.96)
    mean_mean <- mean_data
    mean_shape <- mean_mean^2/(mean_sd^2)
    mean_rate <- mean_mean/(mean_sd^2)
    meanx <- rgamma(1, mean_shape, mean_rate)
    meanx
    mean_data
    ####### try gamma distribution for standard deviation
    #####gamma shape=mean^2/sd^2  gamma rate=mean/sd^2
    sd_sd <- (sd_data_uci-sd_data_lci)/(2*1.96)
    sd_mean <- sd_data
    sd_shape <- sd_mean^2/(sd_sd^2)
    sd_rate <- sd_mean/(sd_sd^2)
    sdx <- rgamma(1, sd_shape, sd_rate)
    v <- sdx^2
    sigmax <- sqrt(log(v/(meanx^2)+1))
    mux <- log(meanx) - (sigmax)^2/2
    B=data.frame(SI=rlnorm(n_primary_samples, mux, sigmax))
    sims1 <- rbind(sims1, B)
  }
  summary(sims1)
  sims1x <- as.data.frame(sims1)
  sims1x$study <- names_df_lnorm_mean_sd[i]
  name_csv <- paste("SI", names_df_lnorm_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims1x, file.path(path_out, name_csv))
  
  strap_si <- data.frame()
  for(k in 1:n_bootstrap_runs){
    a <- sample_n(sims1, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(mean=mean(a$SI, na.rm=T), 
                    sd=sd(a$SI, na.rm=T),
                    X2.5=quantile(a$SI, probs=0.025, na.rm=T),
                    X25=quantile(a$SI, probs=0.25, na.rm=T),
                    X50=quantile(a$SI, probs=0.5, na.rm=T),
                    X75=quantile(a$SI, probs=0.75, na.rm=T),
                    X97.5=quantile(a$SI, probs=0.975, na.rm=T),
                    n_samples=length(a$SI[!is.na(a$SI)]),
                    n_SI_neg=sum(a$SI<0, na.rm=T))
                     Ax$prop_SI_neg <- Ax$n_SI_neg/Ax$n_samples
    strap_si=bind_rows(strap_si, Ax)
  }
  
  melt_strap_si <- melt(strap_si)
  summary_table_si <- melt_strap_si  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  names_df_lnorm_mean_sd[i]
  summary_table_si$study <- names_df_lnorm_mean_sd[i]
  collection_si2 <- rbind(collection_si2, summary_table_si)
  ######## transmission relative to symptoms plus bootstrap
  TRS <- sims1$SI-sims$IP
  sims2 <- data.frame(TRS=TRS)
  sims2x <- as.data.frame(sims2)
  sims2x$study <- names_df_lnorm_mean_sd[i]
  name_csv <- paste("TRS", names_df_lnorm_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims2x, file.path(path_out, name_csv))
  sum(TRS<0, na.rm=T)
  strap_trs <- data.frame()
  
  for(l in 1:n_bootstrap_runs){
    a <- sample_n(sims2, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(meanx=mean(a$TRS, na.rm=T), 
                    sdx=sd(a$TRS, na.rm=T),
                    X2.5=quantile(a$TRS, probs=0.025, na.rm=T),
                    X25=quantile(a$TRS, probs=0.25, na.rm=T),
                    X50=quantile(a$TRS, probs=0.5, na.rm=T),
                    X75=quantile(a$TRS, probs=0.75, na.rm=T),
                    X97.5=quantile(a$TRS, probs=0.975, na.rm=T),
                    n_samples=length(a$TRS[!is.na(a$TRS)]),
                    n_trs_neg=sum(a$TRS<0, na.rm=T))
    Ax$prop_trs_neg <- Ax$n_trs_neg/Ax$n_samples
    strap_trs=bind_rows(strap_trs, Ax)
  }
  name_csv <- paste("strap_TRS", names_df_lnorm_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(strap_trs, file.path(path_out, name_csv))
  
  melt_strap_trs <- melt(strap_trs)
  summary_table_trs <- melt_strap_trs  %>%  
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  summary_table_trs$study <- names_df_lnorm_mean_sd[i]
  
  collection_trs2 <- rbind(collection_trs2, summary_table_trs)
  
}

#######################################################################################################################
######## lognormal with lognormal parameters "Wu et al. [14]" 
df_lnorm_ml_sdl <- d[d$distribution=="lognormal" & d$unique_id=="Wu et al. [14]" ,]
names_df_lnorm_ml_sdl <- unique(df_lnorm_ml_sdl$unique_id)
names_df_lnorm_ml_sdl
collection_si4 <- data.frame()
collection_trs4 <- data.frame()

for (i in 1:length(names_df_lnorm_ml_sdl))
{
  df1 <- d[d$unique_id==names_df_lnorm_ml_sdl[i],]
  summary(as.factor(df1$variable))
  ml_data <- df1$central_value[df1$variable=="parameter.1"] 
  ml_data_lci <-  df1$lower_confidence_interval[df1$variable=="parameter.1"] 
  ml_data_uci <-  df1$upper_confidence_interval[df1$variable=="parameter.1"] 
  sdl_data<- df1$central_value[df1$variable=="parameter.2"]
  sdl_data_lci <- df1$lower_confidence_interval[df1$variable=="parameter.2"]
  sdl_data_uci <- df1$upper_confidence_interval[df1$variable=="parameter.2"]

  sims1 <- data.frame ()
  for (j in 1:n_primary_runs){
    mux <- rnorm(1, ml_data, (ml_data_uci-ml_data_lci)/(2*1.96))
    sigmax <- rnorm(1, sdl_data, (sdl_data_uci-sdl_data_lci)/(2*1.96))
    B=data.frame(SI=rlnorm(n_primary_samples, mux, sigmax))
    sims1 <- rbind(sims1, B)
    summary(sims1)
  }
  summary(sims1)
  sims1x <- as.data.frame(sims1)
  sims1x$study <- names_df_lnorm_ml_sdl[i]
  name_csv <- paste("SI", names_df_lnorm_ml_sdl[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims1x, file.path(path_out, name_csv))
  
  strap_si <- data.frame()
  for(k in 1:n_bootstrap_runs){
    a <- sample_n(sims1, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(mean=mean(a$SI, na.rm=T), 
                    sd=sd(a$SI, na.rm=T),
                    X2.5=quantile(a$SI, probs=0.025, na.rm=T),
                    X25=quantile(a$SI, probs=0.25, na.rm=T),
                    X50=quantile(a$SI, probs=0.5, na.rm=T),
                    X75=quantile(a$SI, probs=0.75, na.rm=T),
                    X97.5=quantile(a$SI, probs=0.975, na.rm=T),
    n_samples=length(a$SI[!is.na(a$SI)]),
    n_SI_neg=sum(a$SI<0, na.rm=T))
Ax$prop_SI_neg <- Ax$n_SI_neg/Ax$n_samples
    
    
    strap_si=bind_rows(strap_si, Ax)
  }
  
  melt_strap_si <- melt(strap_si)
  summary_table_si <- melt_strap_si  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  names_df_lnorm_ml_sdl[i]
  summary_table_si$study <- names_df_lnorm_ml_sdl[i]
  collection_si4 <- rbind(collection_si4, summary_table_si)
  ######## transmission relative to symptoms plus bootstrap
  TRS <- sims1$SI-sims$IP
  summary(TRS)
  length(TRS)
  sims2 <- data.frame(TRS=TRS)
  sims2x <- as.data.frame(sims2)
  sims2x$study <- names_df_lnorm_ml_sdl[i]
  name_csv <- paste("TRS", names_df_lnorm_ml_sdl[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims2x, file.path(path_out, name_csv))
  sum(TRS<0, na.rm=T)
  strap_trs <- data.frame()
  
  for(l in 1:n_bootstrap_runs){
    a <- sample_n(sims2, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(meanx=mean(a$TRS, na.rm=T), 
                    sdx=sd(a$TRS, na.rm=T),
                    X2.5=quantile(a$TRS, probs=0.025, na.rm=T),
                    X25=quantile(a$TRS, probs=0.25, na.rm=T),
                    X50=quantile(a$TRS, probs=0.5, na.rm=T),
                    X75=quantile(a$TRS, probs=0.75, na.rm=T),
                    X97.5=quantile(a$TRS, probs=0.975, na.rm=T),
                    n_samples=length(a$TRS[!is.na(a$TRS)]),
                    n_trs_neg=sum(a$TRS<0, na.rm=T))
    Ax$prop_trs_neg <- Ax$n_trs_neg/Ax$n_samples
    strap_trs=bind_rows(strap_trs, Ax)
  }
  name_csv <- paste("strap_TRS", names_df_lnorm_ml_sdl[i], i, ".csv", sep="_")
  name_csv
  write.csv(strap_trs, file.path(path_out, name_csv))
  
  melt_strap_trs <- melt(strap_trs)
  summary_table_trs <- melt_strap_trs  %>%  
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  summary_table_trs$study <- names_df_lnorm_ml_sdl[i]
  
  collection_trs4 <- rbind(collection_trs4, summary_table_trs)
  
}

#######################################################################################################################
######## shifted lognormal with lognormal parameters "Chun et al" 
df_shifted_lnorm_ml_sdl <- d[d$distribution=="shifted lognormal",]
names_df_shifted_lnorm_ml_sdl <- unique(df_shifted_lnorm_ml_sdl$unique_id)
names_df_shifted_lnorm_ml_sdl
collection_si5 <- data.frame()
collection_trs5 <- data.frame()

for (i in 1:length(names_df_shifted_lnorm_ml_sdl))
{
  df1 <- d[d$unique_id==names_df_shifted_lnorm_ml_sdl[1],]
  summary(as.factor(df1$variable))
  ml_data <- df1$central_value[df1$variable=="parameter.1"] 
  ml_data_lci <-  df1$lower_confidence_interval[df1$variable=="parameter.1"] 
  ml_data_uci <-  df1$upper_confidence_interval[df1$variable=="parameter.1"] 
  sdl_data<- df1$central_value[df1$variable=="parameter.2"]
  sdl_data_lci <- df1$lower_confidence_interval[df1$variable=="parameter.2"]
  sdl_data_uci <- df1$upper_confidence_interval[df1$variable=="parameter.2"]
  sims1 <- data.frame ()
  for (j in 1:n_primary_runs){
    mux <- rnorm(1, ml_data, (ml_data_uci-ml_data_lci)/(2*1.96))
    sigmax <- rnorm(1, sdl_data, (sdl_data_uci-sdl_data_lci)/(2*1.96))
    B=data.frame(SI=rlnorm(n_primary_samples, mux, sigmax)-3.1)#################################
    ##### shift parameter from chun et al =3.1
    sims1 <- rbind(sims1, B)
    #jhsummary(sims1)
   # sd(sims1$SI)
    #hist(sims1$SI, breaks=1000, xlim=c(-5, 20))
  }
  summary(sims1)
  sims1x <- as.data.frame(sims1)
  sims1x$study <- names_df_shifted_lnorm_ml_sdl[i]
  name_csv <- paste("SI", names_df_shifted_lnorm_ml_sdl[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims1x, file.path(path_out, name_csv))
  
  strap_si <- data.frame()
  for(k in 1:n_bootstrap_runs){
    a <- sample_n(sims1, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(mean=mean(a$SI, na.rm=T), 
                    sd=sd(a$SI, na.rm=T),
                    X2.5=quantile(a$SI, probs=0.025, na.rm=T),
                    X25=quantile(a$SI, probs=0.25, na.rm=T),
                    X50=quantile(a$SI, probs=0.5, na.rm=T),
                    X75=quantile(a$SI, probs=0.75, na.rm=T),
                    X97.5=quantile(a$SI, probs=0.975, na.rm=T),
                    n_samples=length(a$SI[!is.na(a$SI)]),
                    n_SI_neg=sum(a$SI<0, na.rm=T))
    Ax$prop_SI_neg <- Ax$n_SI_neg/Ax$n_samples
    
    
    strap_si=bind_rows(strap_si, Ax)
  }
  
  melt_strap_si <- melt(strap_si)
  summary_table_si <- melt_strap_si  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  names_df_shifted_lnorm_ml_sdl[i]
  summary_table_si$study <- names_df_shifted_lnorm_ml_sdl[i]
  collection_si5 <- rbind(collection_si5, summary_table_si)
  ######## transmission relative to symptoms plus bootstrap
  TRS <- sims1$SI-sims$IP
  summary(TRS)
  length(TRS)
  sims2 <- data.frame(TRS=TRS)
  sims2x <- as.data.frame(sims2)
  sims2x$study <- names_df_shifted_lnorm_ml_sdl[i]
  name_csv <- paste("TRS", names_df_shifted_lnorm_ml_sdl[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims2x, file.path(path_out, name_csv))
  sum(TRS<0, na.rm=T)
  strap_trs <- data.frame()
  
  for(l in 1:n_bootstrap_runs){
    a <- sample_n(sims2, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(meanx=mean(a$TRS, na.rm=T), 
                    sdx=sd(a$TRS, na.rm=T),
                    X2.5=quantile(a$TRS, probs=0.025, na.rm=T),
                    X25=quantile(a$TRS, probs=0.25, na.rm=T),
                    X50=quantile(a$TRS, probs=0.5, na.rm=T),
                    X75=quantile(a$TRS, probs=0.75, na.rm=T),
                    X97.5=quantile(a$TRS, probs=0.975, na.rm=T),
                    n_samples=length(a$TRS[!is.na(a$TRS)]),
                    n_trs_neg=sum(a$TRS<0, na.rm=T))
    Ax$prop_trs_neg <- Ax$n_trs_neg/Ax$n_samples
    strap_trs=bind_rows(strap_trs, Ax)
  }
  name_csv <- paste("strap_TRS", names_df_shifted_lnorm_ml_sdl[i], i, ".csv", sep="_")
  name_csv
  write.csv(strap_trs, file.path(path_out, name_csv))
  
  melt_strap_trs <- melt(strap_trs)
  summary_table_trs <- melt_strap_trs  %>%  
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  summary_table_trs$study <- names_df_shifted_lnorm_ml_sdl[i]
  
  collection_trs5 <- rbind(collection_trs5, summary_table_trs)
  
}



##############################################################################################################
######################## Weibull distribution #################################################################

##### Weibull mean and sd
#mean <- 4.8
#sd <- 2.3
#wp <- weibullpar(mean, sd)
#wp$shape
#wp$scale
#wp$loc

###### Weibull distribution with mean and standard deviation - Nishiura 18

summary(as.factor(d$distribution))

df_weibull_mean_sd <- d[d$distribution=="weibull",]
names_df_weibull_mean_sd <- unique(df_weibull_mean_sd$unique_id)
names_df_weibull_mean_sd ### wang
collection_si3 <- data.frame()
collection_trs3 <- data.frame()

for (i in 1:length(names_df_weibull_mean_sd))
{
  df1 <- d[d$unique_id==names_df_weibull_mean_sd[i],]
  mean_data <- df1$central_value[df1$variable=="Mean..95..CI...days."] 
  mean_data_lci <-  df1$lower_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  mean_data_uci <-  df1$upper_confidence_interval[df1$variable=="Mean..95..CI...days."] 
  sd_data<- df1$central_value[df1$variable=="SD"]
  sd_data_lci <- df1$lower_confidence_interval[df1$variable=="SD"]
  sd_data_uci <- df1$upper_confidence_interval[df1$variable=="SD"]
  
  
  sims1 <- data.frame ()
  for (j in 1:n_primary_runs){
    ##### mean has to be non negative for weibull distribution - so try gamma approach like for sd
    mean_sd <- (mean_data_uci-mean_data_lci)/(2*1.96)
    mean_mean <- mean_data
    mean_shape <- mean_mean^2/(mean_sd^2)
    mean_rate <- mean_mean/(mean_sd^2)
    meanx <- rgamma(1, mean_shape, mean_rate)
    meanx
    mean_data
    ####### try gamma distribution for standard deviation
    #####gamma shape=mean^2/sd^2  gamma rate=mean/sd^2
    sd_sd <- (sd_data_uci-sd_data_lci)/(2*1.96)
    sd_mean <- sd_data
    sd_shape <- sd_mean^2/(sd_sd^2)
    sd_rate <- sd_mean/(sd_sd^2)
    sdx <- rgamma(1, sd_shape, sd_rate)
    sdx
    sd_data
    wp <- weibullpar(meanx, sdx)
    shapex <- wp$shape
    shapex
    scalex <- wp$scale
    scalex
    B=data.frame(SI=rweibull(n_primary_samples, shapex, scalex))
    summary(B)
    sims1 <- rbind(sims1, B)
    summary(sims1)
  }

  nrow(sims1)
  sims1x <- as.data.frame(sims1)
  sims1x$study <- names_df_weibull_mean_sd[i]
  name_csv <- paste("SI", names_df_weibull_mean_sd[i], i, ".csv", sep="_")
  name_csv

  write.csv(sims1x, file.path(path_out, name_csv))
  
  strap_si <- data.frame()
  for(k in 1:n_bootstrap_runs){
    a <- sample_n(sims1, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(mean=mean(a$SI, na.rm=T), 
                    sd=sd(a$SI, na.rm=T),
                    X2.5=quantile(a$SI, probs=0.025, na.rm=T),
                    X25=quantile(a$SI, probs=0.25, na.rm=T),
                    X50=quantile(a$SI, probs=0.5, na.rm=T),
                    X75=quantile(a$SI, probs=0.75, na.rm=T),
                    X97.5=quantile(a$SI, probs=0.975, na.rm=T),
    n_samples=length(a$SI[!is.na(a$SI)]),
    n_SI_neg=sum(a$SI<0, na.rm=T))
Ax$prop_SI_neg <- Ax$n_SI_neg/Ax$n_samples
    strap_si=bind_rows(strap_si, Ax)
  }
  
  melt_strap_si <- melt(strap_si)
  summary_table_si <- melt_strap_si  %>%  #### summary at estimate level - that is based on each serial interval or generation time estimate
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  names_df_weibull_mean_sd[i]
  summary_table_si$study <- names_df_weibull_mean_sd[i]
  collection_si3 <- rbind(collection_si3, summary_table_si)
  ######## transmission relative to symptoms plus bootstrap
  TRS <- sims1$SI-sims$IP
  summary(TRS)
  length(TRS)
  sims2 <- data.frame(TRS=TRS)
  sims2x <- as.data.frame(sims2)
  sims2x$study <- names_df_weibull_mean_sd[i]
  name_csv <- paste("TRS", names_df_weibull_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(sims2x, file.path(path_out, name_csv))
  summary(sims2x)
  sum(TRS<0, na.rm=T)
  strap_trs <- data.frame()
  
  for(l in 1:n_bootstrap_runs){
    a <- sample_n(sims2, n_bootstrap_samples, replace=TRUE)
    summary(a)
    Ax = data.frame(meanx=mean(a$TRS, na.rm=T), 
                    sdx=sd(a$TRS, na.rm=T),
                    X2.5=quantile(a$TRS, probs=0.025, na.rm=T),
                    X25=quantile(a$TRS, probs=0.25, na.rm=T),
                    X50=quantile(a$TRS, probs=0.5, na.rm=T),
                    X75=quantile(a$TRS, probs=0.75, na.rm=T),
                    X97.5=quantile(a$TRS, probs=0.975, na.rm=T),
                    n_samples=length(a$TRS[!is.na(a$TRS)]),
                    n_trs_neg=sum(a$TRS<0, na.rm=T))
    Ax$prop_trs_neg <- Ax$n_trs_neg/Ax$n_samples
    strap_trs=bind_rows(strap_trs, Ax)
  }
  name_csv <- paste("strap_TRS", names_df_weibull_mean_sd[i], i, ".csv", sep="_")
  name_csv
  write.csv(strap_trs, file.path(path_out, name_csv))

summary(strap_trs)  
  melt_strap_trs <- melt(strap_trs)
  summary_table_trs <- melt_strap_trs  %>%  
    group_by(variable) %>%
    summarise(n_samples=n(),
              meanx=mean(value),
              sdx=sd(value),
              lci=meanx-1.96*sdx,
              uci=meanx+1.96*sdx)
  
  summary_table_trs$study <- names_df_weibull_mean_sd[i]
  
  collection_trs3 <- rbind(collection_trs3, summary_table_trs)
}

summary(TRS)
length(TRS)

si_df <- rbind(collection_si, collection_si1, collection_si2, collection_si3, collection_si4, collection_si5)
trs_df <- rbind(collection_trs, collection_trs1, collection_trs2, collection_trs3, collection_trs4, collection_trs5)
#setwd("~/Documents/covid_19/r_files/SARS_CoV-2_presym_data_and_code")
write.csv(si_df, file.path(path_out, "si_df.csv"))
write.csv(trs_df, file.path(path_out, "trs_df.csv"))









